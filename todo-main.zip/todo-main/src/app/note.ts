export interface Note{
    id:string;
    note_title:string;
    note_dec:string;
}